// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

#define BOOST_TEST_MODULE diskann_unit_tests

#include <boost/test/unit_test.hpp>
