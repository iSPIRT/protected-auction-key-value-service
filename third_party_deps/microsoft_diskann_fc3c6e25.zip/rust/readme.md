
# readme

run commands under disnann_rust directory.

build:
```
cargo build // Debug

cargo build -r // Release
```


run:
```
cargo run // Debug

cargo run -r // Release
```


test:
```
cargo test
```
