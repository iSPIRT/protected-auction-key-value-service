/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT license.
 */
pub trait Scratch {
    fn clear(&mut self);
}

