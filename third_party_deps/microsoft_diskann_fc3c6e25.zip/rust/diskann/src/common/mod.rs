/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT license.
 */
mod aligned_allocator;
pub use aligned_allocator::AlignedBoxWithSlice;

mod ann_result;
pub use ann_result::*;
